import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Analyse von Spielsituationen auf einem Spielfeld.
 * 
 * @author Fredrik Winkler
 * @version 4. Januar 2007
 */
class SpielfeldAnalyse
{
    private final Spielfeld _spielfeld;
    private Kombination _vierer;

    /**
     * Erstellt eine neue SpielfeldAnalyse.
     * 
     * @param spielfeld
     *            das Spielfeld, das analysiert werden soll
     */
    public SpielfeldAnalyse(Spielfeld spielfeld)
    {
        _spielfeld = spielfeld;
    }

    /**
     * Ueberprueft, ob ein Spieler gewonnen hat.
     */
    public boolean hatSpielerGewonnen(int spieler)
    {
        return bewerte(spieler).gibAnzahl(4) > 0;
    }

    /**
     * Gibt die letzte gefundene Vierer-Kombination.
     */
    public Kombination gibVierer()
    {
        return _vierer;
    }

    /**
     * Analysiert das Spielfeld und liefert den besten Zug.
     * 
     * @param tiefe
     *            die maximale Tiefe des zu berechnenden Analysebaums. 0 bedeutet, dass nur der
     *            eigene Zug beachtet wird.
     * @return die Spalte, in welcher der naechste Zug erfolgen sollte
     */
    public int besterZug(int spieler, int tiefe)
    {
        return besteBewertung(spieler, tiefe).gibBestenZug();
    }

    private Bewertungsfilter besteBewertung(int spieler, int tiefe)
    {
        final int gegner = 3 - spieler;
        final Bewertungsfilter filter = new Bewertungsfilter();
        for (int spalte = 0; spalte < Spielfeld.BREITE; ++spalte)
        {
            if (_spielfeld.istSpalteFrei(spalte))
            {
                _spielfeld.legeSpielsteinAb(spalte, spieler);

                Bewertung bewertung = bewerte(spieler);
                if (tiefe > 0 && bewertung.gibAnzahl(4) == 0 && !_spielfeld.istSpielfeldVoll())
                {
                    bewertung = besteBewertung(gegner, tiefe - 1).gibBesteBewertung();
                    bewertung.negiere();
                }
                else
                {
                    bewertung.subtrahiere(bewerte(gegner));
                }
                filter.registriere(spalte, bewertung);

                _spielfeld.entferneOberstenSpielstein(spalte);
            }
        }
        return filter;
    }

    private Bewertung bewerte(int spieler)
    {
        final Bewertung bewertung = new Bewertung();

        zaehle(spieler, bewertung, 0, 0, 6, 1, 0, 1);
        zaehle(spieler, bewertung, 0, 0, 1, 7, 1, 0);

        zaehle(spieler, bewertung, 0, 0, 3, 1, 1, 1);
        zaehle(spieler, bewertung, 0, 1, 1, 4, 1, 1);

        zaehle(spieler, bewertung, 3, 0, 6, 1, -1, 1);
        zaehle(spieler, bewertung, 5, 1, 6, 4, -1, 1);

        return bewertung;
    }

    private void zaehle(int spieler, Bewertung bewertung, int zeile, int spalte, int zeile2,
            int spalte2, int dZeile, int dSpalte)
    {
        for (int z = zeile; z < zeile2; ++z)
        {
            for (int s = spalte; s < spalte2; ++s)
            {
                zaehle(spieler, bewertung, z, s, dZeile, dSpalte);
            }
        }
    }

    private void zaehle(int spieler, Bewertung bewertung, int zeile, int spalte, int dZeile,
            int dSpalte)
    {
        final int gegner = 3 - spieler;
        int kombination = 0, laenge = 0;
        while (zeile >= 0 && zeile < Spielfeld.HOEHE && spalte >= 0 && spalte < Spielfeld.BREITE)
        {
            int besitzer = _spielfeld.gibBesitzer(zeile, spalte);
            zeile += dZeile;
            spalte += dSpalte;
            if (besitzer == gegner)
            {
                kombination = 0;
                laenge = 0;
            }
            else
            {
                if (besitzer == spieler)
                {
                    ++kombination;
                }
                if (++laenge >= 4)
                {
                    if (kombination == 4)
                    {
                        _vierer = new Kombination(zeile - 4 * dZeile, spalte - 4 * dSpalte, dZeile,
                                dSpalte);
                    }
                    bewertung.registriere(kombination);
                    besitzer = _spielfeld.gibBesitzer(zeile - 4 * dZeile, spalte - 4 * dSpalte);
                    if (besitzer == spieler)
                    {
                        --kombination;
                    }
                }
            }
        }
    }
}

/**
 * Jede Kombination (1er, 2er, 3er, 4er) wird in dieser Klasse mit der Anzahl ihres Auftretens
 * vermerkt.
 * 
 * @author Fredrik Winkler
 * @version 16. Dezember 2007
 */
class Bewertung implements Comparable<Bewertung>
{
    private final int[] n;

    /**
     * Erstellt eine neue Bewertung, in der alle Kombinationen mit 0 initialisiert sind.
     */
    public Bewertung()
    {
        n = new int[5];
    }

    /**
     * Liefert eine Bewertung, die so schlecht ist, dass jeder aus einer echten Analyse
     * hervorgehenden Bewertung der Vorzug gegeben wird.
     */
    public static Bewertung minimum()
    {
        Bewertung b = new Bewertung();
        b.n[4] = -Integer.MAX_VALUE;
        return b;
    }

    /**
     * Registriert eine gefundene Kombination.
     */
    public void registriere(int kombination)
    {
        ++n[kombination];
    }

    /**
     * Liefert die Anzahl der gefundenen Kombinationen.
     */
    public int gibAnzahl(int kombination)
    {
        return n[kombination];
    }

    /**
     * Negiert die Bewertung und liefert sich selbst zurueck.
     */
    public void negiere()
    {
        n[1] = -n[1];
        n[2] = -n[2];
        n[3] = -n[3];
        n[4] = -n[4];
    }

    /**
     * Zieht eine andere Bewertung von dieser Bewertung ab.
     */
    public void subtrahiere(Bewertung bewertung)
    {
        n[1] -= bewertung.n[1];
        n[2] -= bewertung.n[2];
        n[3] -= bewertung.n[3];
        n[4] -= bewertung.n[4];
    }

    /**
     * @see Comparable.compareTo(T o)
     */
    public int compareTo(Bewertung m)
    {
        if (n[4] > m.n[4]) return 1;
        if (n[4] < m.n[4]) return -1;
        if (n[3] > m.n[3]) return 1;
        if (n[3] < m.n[3]) return -1;
        if (n[2] > m.n[2]) return 1;
        if (n[2] < m.n[2]) return -1;
        if (n[1] > m.n[1]) return 1;
        if (n[1] < m.n[1]) return -1;
        return 0;
    }
}

/**
 * Exemplare dieser Klasse werden mit den Bewertungen fuer alle Spalten gefuettert. Aus diesen
 * werden alle gleich guten, besten Bewertungen gespeichert, so dass man sich zufaellig fuer eine
 * entscheiden kann.
 * 
 * Diese Klasse ist notwendig, um eine echte Gleichverteilung der als aequivalent eingestuften,
 * optimalen Spielzuegen erreichen zu koennen.
 * 
 * @author Fredrik Winkler
 * @version 16. Dezember 2007
 */
class Bewertungsfilter
{
    private Bewertung _optimum;
    private final List<Integer> _spalten;

    public Bewertungsfilter()
    {
        _optimum = Bewertung.minimum();
        _spalten = new ArrayList<Integer>();
    }

    /**
     * Registriert eine Bewertung in einer Spalte.
     */
    public void registriere(int spalte, Bewertung bewertung)
    {
        final int differenz = bewertung.compareTo(_optimum);
        if (differenz > 0)
        {
            _optimum = bewertung;
            _spalten.clear();
            _spalten.add(spalte);
        }
        else if (differenz == 0)
        {
            _spalten.add(spalte);
        }
    }

    /**
     * Liefert die beste bisher gefundene Bewertung.
     */
    public Bewertung gibBesteBewertung()
    {
        return _optimum;
    }

    /**
     * Liefert eine zufaelligen Zug aus den als gleich eingestuften Bewertungen.
     * 
     * @return die Spalte, in welcher der naechste Zug erfolgen sollte
     */
    public int gibBestenZug()
    {
        return _spalten.get(zufall.nextInt(_spalten.size()));
    }

    private static final Random zufall = new Random();
}

/**
 * Werttyp, der eine beliebige Kombination auf dem Spielfeld speichert.
 * 
 * @author Fredrik Winkler
 * @version 18. Dezember 2007
 */
class Kombination
{
    public final int zeile, spalte, dZeile, dSpalte;

    /**
     * Erzeugt eine neue Kombination.
     * 
     * @param zeile
     *            Startposition
     * @param spalte
     *            Startposition
     * @param dZeile
     *            Richtung
     * @param dSpalte
     *            Richtung
     */
    public Kombination(int zeile, int spalte, int dZeile, int dSpalte)
    {
        this.zeile = zeile;
        this.spalte = spalte;
        this.dZeile = dZeile;
        this.dSpalte = dSpalte;
    }
}
