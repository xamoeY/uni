/**
 * Eine Testklasse fuer Spielfeld-Klassen.
 *
 * @author Christian Spaeh
 * @author Fredrik Winkler
 * @version 5. Dezember 2011
 */
public class SpielfeldTest extends junit.framework.TestCase
{
    private final Spielfeld _spielfeld;

    /**
     * Jede Testmethode arbeitet auf einem frisch erzeugten Test-Exemplar.
     * Im Konstruktor kann man also den erforderlichen Ausgangszustand
     * fuer die einzelnen Testmethoden herstellen, in diesem Fall ein neues Spielfeld.
     */
    public SpielfeldTest()
    {
        _spielfeld = new Spielfeld();
    }

    /**
     * Wenn alle Positionen besetzt sind, solle das Spielfeld voll sein.
     * Vorher sollte es immer leer sein.
     */
    public void testBefuelleSpielfeldKomplett()
    {
        for (int zeile = 0; zeile < 3; ++zeile)
        {
            for (int spalte = 0; spalte < 3; ++spalte)
            {
                assertFalse(_spielfeld.istVoll());
                _spielfeld.besetzePosition(zeile, spalte, 1);
            }
        }
        assertTrue(_spielfeld.istVoll());
    }

    /**
     * Wenn neun Mal dieselbe Position besetzt wird,
     * sollte das Spielfeld nicht voll sein.
     */
    public void testBesetzeNeunMalDieselbePosition()
    {
        for (int i = 0; i < 9; ++i)
        {
            _spielfeld.besetzePosition(0, 0, 1);
        }
        assertFalse(_spielfeld.istVoll());
    }

    /**
     * Schreibt in diesen Kommentar, was diese Methode testet:
     * 
     * 
     */
    public void test3()
    {
        for (int zeile = 0; zeile < 3; ++zeile)
        {
            for (int spalte = 0; spalte < 3; ++spalte)
            {
                assertEquals(0, _spielfeld.gibBesitzer(zeile, spalte));

                _spielfeld.besetzePosition(zeile, spalte, 1);
                assertEquals(1, _spielfeld.gibBesitzer(zeile, spalte));

                _spielfeld.besetzePosition(zeile, spalte, 2);
                assertEquals(2, _spielfeld.gibBesitzer(zeile, spalte));

                _spielfeld.besetzePosition(zeile, spalte, 0);
                assertEquals(0, _spielfeld.gibBesitzer(zeile, spalte));
            }
        }
    }
}
