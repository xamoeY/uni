/**
 * Ein einfaches Konto. Es kann abgehoben und eingezahlt werden.
 * Das Konto kann ueberzogen werden und speichert den Saldo als Integer.
 * 
 * @author Martti Jeenicke, Fredrik Winkler
 * @version 2004-03-19
 */
class Konto
{
    // der ganzzahlige Saldo
    private int _saldo;

    /**
     * Erzeugt ein neues, leeres Konto
     */
    public Konto()
    {
        _saldo = 0;
    }

    /**
     * Erzeugt ein neues Konto mit einem Startguthaben
     * 
     * @param startguthaben das gewuenschte Startguthaben
     */
    public Konto(int startguthaben)
    {
        _saldo = startguthaben;
    }

    /**
     * Zahlt einen Betrag auf das Konto ein
     * 
     * @param betrag der einzuzahlende Betrag
     */
    public void zahleEin(int betrag)
    {
        if (betrag >= 0)
        {
            _saldo = _saldo + betrag;
        }
        else
        {
            System.out.println("Fehler: Es kann kein negativer Betrag eingezahlt werden");
        }
    }

    /**
     * Hebt einen Betrag vom Konto ab
     * 
     * @param betrag der abzuhebende Betrag
     */
    public void hebeAb(int betrag)
    {
        if (betrag >= 0)
        {
            _saldo = _saldo - betrag;
        }
        else
        {
            System.out.println("Fehler: Es kann kein negativer Betrag ausgezahlt werden");
        }
    }
    
    /**
     * Liefert den Saldo des Kontos zurueck
     * 
     * @return der Saldo des Kontos
     */
    public int gibSaldo()
    {
        return _saldo;
    }
}
