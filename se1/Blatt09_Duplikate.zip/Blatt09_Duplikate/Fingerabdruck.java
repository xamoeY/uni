import java.io.*;
import java.security.MessageDigest;

/**
 * Diese Klasse dient zum Generieren von Fingerabdruecken aus Dateien.
 *
 * @author Fredrik Winkler
 * @version 13. Dezember 2011
 */
class Fingerabdruck
{
    /**
     * Generiert aus dem Inhalt einer Datei einen Fingerabdruck.
     * Genau wie bei Menschen ist es extrem unwahrscheinlich,
     * dass inhaltsverschiedene Dateien denselben Fingerabdruck haben.
     * 
     * @param file die einzulesende Datei
     * @return der Fingerabdruck, sofern alles klappt, ansonsten der Dateiname 
     */
    public static String aus(File file)
    {
        BufferedInputStream in = null;
        try
        {
            MessageDigest digest = MessageDigest.getInstance("SHA");
            in = new BufferedInputStream(new FileInputStream(file));
            int number_of_bytes_read;
            while ((number_of_bytes_read = in.read(buffer)) != -1)
            {
                digest.update(buffer, 0, number_of_bytes_read);
            }
            return asHexString(digest.digest());
        }
        catch (Exception ignore)
        {
            // In seltenen Ausnahmefaellen kommt es zu einer Exception,
            // weil die Datei nicht mehr existiert oder geschuetzt ist.
            return file.toString();
        }
        finally
        {
            closeSilently(in);
        }
    }

    /**
     * Wandelt ein Byte-Array in einen hexadezimalen String um.
     * Arrays sind Sammlungen fester Groesse,
     * die erst spaeter in der Vorlesung drankommen werden.
     */
    private static String asHexString(byte[] bytes)
    {
        StringBuffer result = new StringBuffer(2 * bytes.length);
        for (byte b : bytes)
        {
            result.append("0123456789abcdef".charAt((b >> 4) & 15));
            result.append("0123456789abcdef".charAt(b & 15));
        }
        return result.toString();
    }

    /**
     * Schliesst ggf. eine Datei und ignoriert evtl. dabei auftrende Ausnahmen.
     * Es ist ausdruecklich erlaubt, null zu uebergeben, dann passiert nichts.
     * 
     * @param closeable null oder eine zu schliessende Datei
     */
    private static void closeSilently(Closeable closeable)
    {
        if (closeable != null)
        {
            try
            {
                closeable.close();
            }
            catch (IOException ignore)
            {
            }
        }
    }

    private static final byte[] buffer = new byte[65536];
}
