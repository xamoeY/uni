import java.io.File;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;

/**
 * Ein Duplikatsucher sucht Duplikate in einem Dateisystem.
 *  
 * @author Fredrik Winkler
 * @version 13. Dezember 2011
 */
class Duplikatsucher
{
    private final File _startverzeichnis;
    private final Set<Datei> _originale;
    private final List<Datei> _duplikate;

    /**
     * Initialisiert einen neuen Duplikatsucher,
     * der Duplikate im aktuellen Verzeichnis sucht.
     */
    public Duplikatsucher()
    {
        this(System.getProperty("user.dir"));
    }

    /**
     * Initialisiert einen neuen Duplikatsucher,
     * der Duplikate im angegebenen Startverzeichnis sucht.
     * 
     * @param startverzeichnis hier faengt der Duplikatsucher an
     */
    public Duplikatsucher(String startverzeichnis)
    {
        _startverzeichnis = new File(startverzeichnis);
        if (!_startverzeichnis.exists())
        {
            throw new IllegalArgumentException(_startverzeichnis + " existiert nicht");
        }
        if (!_startverzeichnis.isDirectory())
        {
            throw new IllegalArgumentException(_startverzeichnis + " ist kein Verzeichnis");
        }
        _originale = new HashSet<Datei>();
        _duplikate = new ArrayList<Datei>();
    }

    /**
     * Beginnt die Suche nach Duplikaten.
     */
    public void start()
    {
        System.out.println("Bitte warten...\n");
        untersuche(_startverzeichnis);
        System.out.println("Gefundene Duplikate: " + _duplikate.size());

        _originale.clear();
        _duplikate.clear();
    }

    /**
     * Untersucht alle Files im angegebenen Verzeichnis.
     */
    private void untersuche(File verzeichnis)
    {
        for (File file : verzeichnis.listFiles())
        {
            if (!file.isHidden() && file.canRead())
            {
                if (file.isDirectory())
                {
                    untersuche(file);
                }
                else
                {
                    verarbeite(new Datei(file));
                }
            }
        }
    }

    /**
     * Versucht, die Datei zu den Originalen hinzuzufuegen.
     * Falls das nicht klappt, handelt es sich um ein Duplikat.
     */
    private void verarbeite(Datei datei)
    {
        if (_originale.add(datei) == false)
        {
            duplikatGefunden(datei);
        }
    }

    /**
     * Gibt das Duplikat zusammen mit seiner Kopie aus und merkt sich das Duplikat.
     */
    private void duplikatGefunden(Datei duplikat)
    {
        for (Datei original : _originale)
        {
            if (duplikat.equals(original))
            {
                System.out.println("Original: " + original);
                System.out.println("Duplikat: " + duplikat);
                System.out.println();
            }
        }
        _duplikate.add(duplikat);
    }
}
