/**
 * Diese Klasse testet das Notizbuch.
 *
 * @author  Fredrik Winkler
 * @version 14. Dezember 2011
 */
public class NotizbuchTest extends junit.framework.TestCase
{
    private final Notizbuch _notizbuch;
    
    /**
     * Jede Testmethode arbeitet auf einem frisch erzeugten Exemplar.
     */
    public NotizbuchTest()
    {
        _notizbuch = new Notizbuch();
    }

    /**
     * Testet, ob ein neues Notizbuch leer ist.
     */
    public void testNeuesNotizbuchIstLeer()
    {
        assertEquals(0, _notizbuch.anzahlNotizen());
    }

    /**
     * Testet, ob das Einfuegen am Ende klappt.
     */
    public void testEinfuegenAmEnde()
    {
        _notizbuch.speichereNotiz("hallo");
        _notizbuch.speichereNotiz("welt");
        
        assertEquals(2, _notizbuch.anzahlNotizen());
        
        assertEquals("hallo", _notizbuch.gibNotiz(0));
        assertEquals("welt",  _notizbuch.gibNotiz(1));
    }
    
    /**
     * Testet, ob das Einfuegen am Anfang klappt.
     */
    public void testEinfuegenAmAnfang()
    {
        _notizbuch.speichereNotiz(0, "hallo");
        _notizbuch.speichereNotiz(0, "welt");
        
        assertEquals(2, _notizbuch.anzahlNotizen());
        
        assertEquals("welt",  _notizbuch.gibNotiz(0));
        assertEquals("hallo", _notizbuch.gibNotiz(1));
    }
    
    /**
     * Testet, ob das Einfuegen in der Mitte klappt.
     */
    public void testEinfuegenInDerMitte()
    {
        _notizbuch.speichereNotiz("hallo");
        _notizbuch.speichereNotiz("welt");
        _notizbuch.speichereNotiz(1, "schoene");

        assertEquals(3, _notizbuch.anzahlNotizen());
        
        assertEquals("hallo",   _notizbuch.gibNotiz(0));
        assertEquals("schoene", _notizbuch.gibNotiz(1));
        assertEquals("welt",    _notizbuch.gibNotiz(2));
    }
}
