import java.util.List;
import java.util.ArrayList;

/**
 * Diese Klasse beschreibt beliebig lange Notizlisten.
 * Ein Notizbuch ist wie ein Ringhefter organisiert: Eine Notiz
 * kann an beliebiger Stelle in die Liste eingefuegt werden. 
 * Benutzer koennen auf Notizen anhand ihrer Position zugreifen.
 * Die erste Notiz hat die Position 0.
 * 
 * @author Axel Schmolitzky
 * @author Petra Becker-Pechau
 * @author Christian Spaeh
 * @author Fredrik Winkler
 * @version 13. Dezember 2011
 */
class Notizbuch
{
    // Liste fuer eine beliebige Anzahl an Notizen.
    private List<String> _notizen;

    /**
     * Ein neues Notizbuch enthaelt keine Notizen.
     */
    public Notizbuch()
    {
        _notizen = new ArrayList<String>();
    }

    /**
     * Speichere die gegebene Notiz, indem sie an das Ende der
     * Notizliste dieses Notizbuchs angehaengt wird.
     * 
     * @param notiz die zu speichernde Notiz.
     */
    public void speichereNotiz(String notiz)
    {
        _notizen.add(notiz);
    }

    /**
     * Fuege die gegebene Notiz an der angegebenen Position ein und
     * verschiebe alle nachfolgenden Notizen um eine Position nach hinten.
     * 
     * @param position die Position der neuen Notiz. Bei einem 
     *        Wert groesser AnzahlNotizen wird eine Exception geworfen.
     * @param notiz die zu speichernde Notiz.
     */
    public void speichereNotiz(int position, String notiz)
    {
        if (position < 0 || position > anzahlNotizen())
        {
            throw new IllegalArgumentException("Ungueltige Position!");
        }
        // Die Position ist gueltig, wir koennen die Notiz einfuegen.
        _notizen.add(notiz);
    }
    
    /**
     * Liefert die Anzahl der Notizen in diesem Notizbuch.
     */
    public int anzahlNotizen()
    {
        return _notizen.size();
    }

    /**
     * Gib die Notiz an der gegebenen Position zurueck. Bei einer ungueltigen
     * Position wird eine Exception geworfen.
     * 
     * @param position die Position der Notiz, die zurueckgegeben werden soll.
     */
    public String gibNotiz(int position)
    {
        if (position < 0 || position >= anzahlNotizen())
        {
            throw new IllegalArgumentException("Ungueltige Position!");
        }
        return _notizen.get(position);
    }
}
