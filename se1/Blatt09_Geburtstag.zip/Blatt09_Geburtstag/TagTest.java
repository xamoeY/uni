/**
 * The test class TagTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class TagTest extends junit.framework.TestCase
{
    /**
     * Testet, ob zwei Tag-Exemplare, die denselben Tag repraesentieren,
     * als gleich angesehen werden.
     */
    public void testGleichheit()
    {
    }
    
    /**
     * Testet, ob zwei Tag-Exemplare, die verschiedene Tage repraesentieren,
     * als ungleich angesehen werden.
     */
    public void testUngleichheit()
    {
    }
}
