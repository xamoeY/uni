import java.util.Scanner;

/**
 * Halbwegs sinnvolle Beispiele fuer die Schleifenmechanismen von Java.
 * 
 * @author Fredrik Winkler
 * @version 22. November 2011
 */
class Schleifendreher
{
    // Beispiele fuer for-Schleifen

    /**
     * Gibt die Ziffern 0 bis 9 mit dem Hinweis, dass es sich um Ziffern handelt, auf der Konsole aus.
     */
    public void druckeAlleZiffern()
    {
        for (int i = 0; i < 10; ++i)
        {
            System.out.println(i + " ist eine Ziffer.");
        }
    }

    /**
     * Gibt alle Ziffern, die durch drei teilbar sind, mit entsprechendem Hinweis auf der Konsole aus.
     */
    public void druckeDreierZiffernRueckwaerts()
    {
        // Man kann bei beliebigen Werten anfangen
        // und beliebig grosse Schritte in beide Richtungen gehen.
        for (int i = 9; i >= 0; i -= 3)
        {
            System.out.println(i + " ist durch 3 teilbar.");
        }
    }

    /**
     * Gibt alle Paare nicht-negativer Zahlen, deren Summe 9 ergibt, auf der Konsole aus.
     * Die die Addition kommutativ ist, werden redundante Paare bewusst vermieden.
     */
    public void druckeNeunerSummen()
    {
        // Es koennen beliebig viele Schleifenzaehler verwendet werden,
        // zum Beispiel zwei "gegeneinander laufende" Zaehler,
        // die sich in der Mitte treffen (man beachte die Schleifenbedingung).
        for (int a = 0, b = 9; a < b; ++a, --b)
        {
            System.out.println( a + " + " + b + " = " + (a + b));
        }
    }

    /**
     * Gibt die Buchstaben einer Zeichenkette durch Kommata getrennt auf der Konsole aus.
     */
    public void druckeEinzelneBuchstaben(String text)
    {
        for (int i = 0; i < text.length(); ++i)
        {
            System.out.print(text.charAt(i));
            System.out.print(", ");
        }
        System.out.println();
    }

    
    // Beispiele fuer while-Schleifen

    /**
     * Liefert die kleinste Primzahl, welche groesser oder gleich x ist.
     */
    public int findeNaechstePrimzahl(int x)
    {
        while (!istPrimzahl(x))
        {
            ++x;
        }
        return x;
    }

    /**
     * Gibt fuer eine Zeichenkette, die aus n Zeichen besteht,
     * n Zeilen auf der Konsole aus, wobei nach jeder Zeile
     * das erste Zeichen aus der Zeichenkette entfernt wird.
     */
    public void druckeDreiecksmuster(String text)
    {
        while (!text.isEmpty())
        {
            System.out.println(text);
            text = text.substring(1);
        }
    }


    // Beispiel fuer do-while-Schleifen

    /**
     * Fordert den Benutzer wiederholt zur Eingabe eines Passwortes auf,
     * bis er das korrekte Passwort eingegeben hat.
     */
    public void verlangePasswort()
    {
        String zeile;
        do
        {
            System.out.print("Passwort? ");
            zeile = liesZeileVomBenutzer();
        }
        while (!zeile.equals("\116\151\143\141\162\141\147\165\141"));

        System.out.println("Du darfst eintreten!");
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    // Die folgenden privaten Hilfsmethoden muessen nicht verstanden werden.

    /**
     * Liest eine Zeile von der Konsole ein und liefert sie zurueck.
     */
    private String liesZeileVomBenutzer()
    {
        Scanner scanner = new Scanner(System.in);
        return scanner.nextLine();
    }
    
    /**
     * Bestimmt, ob es sich bei der uebergebenen Zahl um eine Primzahl handelt.
     * Achtung, diese Loesung ist nicht besonders effizient
     * und sollte auf keinen Fall in Produktionscode verwendet werden!
     */
    private boolean istPrimzahl(int x)
    {
        int limit = (int) Math.sqrt(x);
        for (int i = 2; i <= limit; ++i)
        {
            if ((x % i) == 0)
            {
                return false;
            }
        }
        return true;
    }
}
