TASK 2:

For learning the apriori algorithm, take first the data in: toy.mat.

For a more realistic application, use the restaurant data set:

The restaurant data are in: cities_komma.txt
Information about it is in: features.txt
To convert data from cities_komma.txt into binary matrix format as required, use: preprocess_apriori.m
The function in apriori.m calls the functions gen_candidates.m and pruning.m

The restaurant data are from here:
http://archive.ics.uci.edu/ml/datasets/Entree+Chicago+Recommendation+Data


TASK 4

For testing the decision tree algorithm, make use of the data in: autoMPGDataSetSmall.txt 

The data set contains characteristics of cars manufactured in three different continents: America, Asia, and Europe.

Number of instances/observations: 42 

Number of attributes: 8 (7 features, 1 class)

a) Miles per gallon: multi-valued discrete - 0 = bad, 1 = OK, 2 = Good
b) Cylinders: multi-valued discrete
c) Displacement: continuous
d) Horsepower: continuous
e) Weight: continuous
f) Acceleration: continuous
g) Model year: multi-valued discrete
h) Car name: Binary (CLASS!) - 1 = America, 2 = Asia, 3 = Europe

The data stem from the following data base:
http://archive.ics.uci.edu/ml/datasets/Auto+MPG
