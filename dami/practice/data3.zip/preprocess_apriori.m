% transform the value matrix into a binary matrix
% numdata = number of restaurants (4160 for all cities together)
% numfeat = maximum number of features assigned to any restaurant (30 over all cities)
% maxfeatval = largest feature value (the "256" for Yugoslavian)

maxfeatval = 256
featmat = data;
[numdata,numfeat] = size(featmat)
binmat = zeros(numdata,maxfeatval);
for i=1:numdata
    for j=1:numfeat
        if  ~isnan(featmat(i,j))
            binmat(i,featmat(i,j)) = 1;
        end
    end
end

